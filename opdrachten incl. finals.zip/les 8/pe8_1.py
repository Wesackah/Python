oranje = {'Boxtel','Best','Beukenlaan','Eindhoven','Helmond t hout','Helmond','Helmond Brouwhuis','Deurne'}
set()
groen = {'Boxtel','Best','Beukenlaan','Eindhoven', 'Geldrop','Heeze','Weert'}
set()
print(oranje&groen)
print(oranje-groen)
print(oranje|groen)