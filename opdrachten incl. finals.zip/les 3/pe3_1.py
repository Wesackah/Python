score = eval(input('Wat is je score? '))
if score > 15:
    print('Gefeliciteerd!')
    print(f'Met een score van {score} ben je geslaagd!')