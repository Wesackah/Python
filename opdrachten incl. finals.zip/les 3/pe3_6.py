s = "Guido van Rossum heeft programmeertaal Python bedacht."
for i in s:
    if i in 'aieou':
        print(i)