lst = ['maandag', 'dinsdag', 'woensdag']
for i in lst:
    print(i[0] + i[1])