z = eval(input('geef lijst'))
lst = []
for i in z:
    if len(i) == 4:
        lst.append(i)

print(lst)
