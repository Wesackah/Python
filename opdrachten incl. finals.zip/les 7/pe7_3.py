d = {'Kees':'9', 'Hennie':'6', 'Ferdi':'8','Albert':'9.5', 'Sjon':'9.3', 'Jermaine':'5', 'Wu':'10', 'Nina':'1'}
for i in d.values():
    if float(i) >= 9:
        print(i)