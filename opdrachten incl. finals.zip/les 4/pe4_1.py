
def som(getal1, getal2, getal3):
     return getal1 + getal2 + getal3

print(som(5, 6, 5))