lijst = ['a', 'b', 'c']
def wijzig():
    lijst[0] = 'd'
    lijst[1] =' e'
    lijst[2] = 'f'

wijzig()
print(lijst)