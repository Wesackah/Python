def som(getallenLijst):
    return sum(getallenLijst)

print(som([1, 2, 3, 4, 8, 6, 9]))