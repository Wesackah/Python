letters = ('A', 'C', 'B', 'C', 'B', 'A', 'C', 'C', 'B')
telling = [letters.count('A'), letters.count('B'), letters.count('C')]
print(telling)
