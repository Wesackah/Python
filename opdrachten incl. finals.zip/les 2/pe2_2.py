cijferICOR = 7
cijferPROG = 6.5
cijferCSN = 6
gemiddelde = (cijferCSN +cijferPROG + cijferICOR)/3
beloning = 3*gemiddelde*30
overzicht = f"Mijn cijfers (gemiddeld een {gemiddelde}) leveren een beloning van € {beloning} op!"
print(overzicht)
