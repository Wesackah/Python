salaris = eval(input('Wat is je salaris per uur?'))
tijd = eval(input('Hoeveel uur heb je gewerkt?'))
Geld = salaris*tijd
print(f'{tijd} uur werken levert {Geld} Euro op')

