b = 7
def verdubbel(var):
    return var*2

print(verdubbel(b))


def f(y):
    return 2*y + 1

def g(x):
    return 5 + x + 10

print(f(3)+g(3))